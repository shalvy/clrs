import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-register',
  templateUrl: './asset-register.component.html',
  styleUrls: ['./asset-register.component.css']
})
export class AssetRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
