import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-submenu',
  templateUrl: './submenu.component.html',
  styleUrls: ['./submenu.component.css']
})
export class CompanySubmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
