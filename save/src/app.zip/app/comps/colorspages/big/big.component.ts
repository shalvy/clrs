import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-big',
  templateUrl: './big.component.html',
  styleUrls: ['./big.component.css']
})
export class BigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
