import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-setup',
  templateUrl: './setup.component.html',
  styleUrls: ['./setup.component.css']
})
export class PersonalSetupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
