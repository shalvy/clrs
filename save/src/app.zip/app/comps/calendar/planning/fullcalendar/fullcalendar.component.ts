import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullcalendar',
  templateUrl: './fullcalendar.component.html',
  styleUrls: ['./fullcalendar.component.css']
})
export class FullcalendarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
