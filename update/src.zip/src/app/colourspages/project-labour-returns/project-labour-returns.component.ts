import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-labour-returns',
  templateUrl: './project-labour-returns.component.html',
  styleUrls: ['./project-labour-returns.component.css']
})
export class ProjectLabourReturnsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
