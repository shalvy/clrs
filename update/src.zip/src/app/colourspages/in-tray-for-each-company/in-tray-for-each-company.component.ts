import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-tray-for-each-company',
  templateUrl: './in-tray-for-each-company.component.html',
  styleUrls: ['./in-tray-for-each-company.component.css']
})
export class InTrayForEachCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
