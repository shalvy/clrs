import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subsidiaries',
  templateUrl: './subsidiaries.component.html',
  styleUrls: ['./subsidiaries.component.css']
})
export class SubsidiariesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
