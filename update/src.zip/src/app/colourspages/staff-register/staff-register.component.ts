import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staff-register',
  templateUrl: './staff-register.component.html',
  styleUrls: ['./staff-register.component.css']
})
export class StaffRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
