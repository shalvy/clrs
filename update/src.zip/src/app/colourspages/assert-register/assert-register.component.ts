import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assert-register',
  templateUrl: './assert-register.component.html',
  styleUrls: ['./assert-register.component.css']
})
export class AssertRegisterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
