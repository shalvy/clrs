import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ent-projects',
  templateUrl: './ent-projects.component.html',
  styleUrls: ['./ent-projects.component.css']
})
export class EntProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
