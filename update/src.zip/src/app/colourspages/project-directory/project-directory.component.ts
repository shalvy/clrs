import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-directory',
  templateUrl: './project-directory.component.html',
  styleUrls: ['./project-directory.component.css']
})
export class ProjectDirectoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
