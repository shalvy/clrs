import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-schedular',
  templateUrl: './task-schedular.component.html',
  styleUrls: ['./task-schedular.component.css']
})
export class TaskSchedularComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
