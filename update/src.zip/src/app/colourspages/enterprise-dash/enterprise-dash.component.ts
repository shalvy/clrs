import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enterprise-dash',
  templateUrl: './enterprise-dash.component.html',
  styleUrls: ['./enterprise-dash.component.css']
})
export class EnterpriseDashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
