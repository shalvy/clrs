import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-tray-for-whole-project',
  templateUrl: './in-tray-for-whole-project.component.html',
  styleUrls: ['./in-tray-for-whole-project.component.css']
})
export class InTrayForWholeProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
