import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-accounts',
  templateUrl: './client-accounts.component.html',
  styleUrls: ['./client-accounts.component.css']
})
export class ClientAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
