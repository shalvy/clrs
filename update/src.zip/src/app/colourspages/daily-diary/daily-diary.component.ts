import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daily-diary',
  templateUrl: './daily-diary.component.html',
  styleUrls: ['./daily-diary.component.css']
})
export class DailyDiaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
