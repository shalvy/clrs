import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-ent',
  templateUrl: './new-ent.component.html',
  styleUrls: ['./new-ent.component.css']
})
export class NewEntComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
