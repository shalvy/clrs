import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-dash',
  templateUrl: './personal-dash.component.html',
  styleUrls: ['./personal-dash.component.css']
})
export class PersonalDashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
