import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-things-to-do-personal',
  templateUrl: './things-to-do-personal.component.html',
  styleUrls: ['./things-to-do-personal.component.css']
})
export class ThingsToDoPersonalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
