import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-plant-returns',
  templateUrl: './project-plant-returns.component.html',
  styleUrls: ['./project-plant-returns.component.css']
})
export class ProjectPlantReturnsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
