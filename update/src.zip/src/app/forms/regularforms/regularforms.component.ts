import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'regularforms-cmp',
    templateUrl: 'regularforms.component.html'
})

export class RegularFormsComponent{}
