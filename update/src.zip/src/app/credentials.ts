export const firebaseConfig = {
  apiKey: 'AIzaSyDlVk4yyfvfM8Z19BYDt3Zt_LO_I21td7g',
  authDomain: 'colors-a07e8.firebaseapp.com',
  databaseURL: 'https://colors-a07e8.firebaseio.com',
  projectId: 'colors-a07e8',
  storageBucket: 'colors-a07e8.appspot.com',
  messagingSenderId: '848651061453'
};


// <script src="https://www.gstatic.com/firebasejs/4.12.1/firebase.js" > </script>
//   < script >
//   // Initialize Firebase
//   var config = {
//   apiKey: "AIzaSyDlVk4yyfvfM8Z19BYDt3Zt_LO_I21td7g",
//   authDomain: "colors-a07e8.firebaseapp.com",
//   databaseURL: "https://colors-a07e8.firebaseio.com",
//   projectId: "colors-a07e8",
//   storageBucket: "colors-a07e8.appspot.com",
//   messagingSenderId: "848651061453"
// };
// firebase.initializeApp(config);
// </script>
